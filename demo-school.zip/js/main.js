/* ============================================================
   ডেমো সরকারি মডেল পাইলট উচ্চ বিদ্যালয়
   Main JavaScript
   ============================================================ */

// Dynamically load SweetAlert2 from CDN if not already present
if (typeof Swal === 'undefined') {
  const SwalScript = document.createElement('script');
  SwalScript.src = 'https://cdn.jsdelivr.net/npm/sweetalert2@11';
  SwalScript.async = true;
  document.head.appendChild(SwalScript);
}

document.addEventListener('DOMContentLoaded', function () {

  // ============================================================
  // CUTE PRELOADER INJECTION & FADE-OUT (MIN 3 SEC - SESSION INITIAL LOAD ONLY)
  // ============================================================
  const hasLoadedThisSession = sessionStorage.getItem('websiteLoaded');

  if (!hasLoadedThisSession) {
    sessionStorage.setItem('websiteLoaded', 'true');
    const preloaderStartTime = Date.now();
    const preloaderDiv = document.createElement('div');
    preloaderDiv.id = 'preloader';
    preloaderDiv.innerHTML = `
      <div class="preloader-bg-blob preloader-bg-blob--1"></div>
      <div class="preloader-bg-blob preloader-bg-blob--2"></div>
      <div class="preloader-content">
        <div style="display: flex; flex-direction: column; align-items: center; justify-content: center;">
          <div class="book-loader">
            <div class="book-loader__spine"></div>
            <div class="book-loader__page book-loader__page--left"></div>
            <div class="book-loader__page book-loader__page--right"></div>
            <div class="book-loader__page book-loader__page--flip"></div>
          </div>
          <p class="preloader-subtitle">
            <span class="preloader-dots"><span></span><span></span><span></span></span>
          </p>
        </div>
      </div>
    `;
    document.body.prepend(preloaderDiv);

    const hidePreloader = () => {
      const elapsed = Date.now() - preloaderStartTime;
      const delay = Math.max(3000 - elapsed, 0);

      setTimeout(() => {
        preloaderDiv.classList.add('fade-out');
        setTimeout(() => {
          preloaderDiv.remove();
        }, 500);
      }, delay);
    };

    if (document.readyState === 'complete') {
      hidePreloader();
    } else {
      window.addEventListener('load', hidePreloader);
    }
  }

  // ============================================================
  // Mobile Navigation Toggle
  // ============================================================
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', function () {
      this.classList.toggle('active');
      navMenu.classList.toggle('active');
    });

    // Mobile dropdown toggles
    const dropdownParents = navMenu.querySelectorAll('.nav-menu__item');
    dropdownParents.forEach(function (item) {
      const link = item.querySelector('.nav-menu__link');
      const dropdown = item.querySelector('.nav-dropdown');

      if (link && dropdown) {
        link.addEventListener('click', function (e) {
          if (window.innerWidth <= 768) {
            if (link.getAttribute('href') === '#' || link.querySelector('.arrow')) {
              e.preventDefault();
              dropdown.classList.toggle('mobile-open');
            }
          }
        });
      }
    });
  }

  // Close mobile menu on click outside
  document.addEventListener('click', function (e) {
    if (navMenu && navToggle && !navMenu.contains(e.target) && !navToggle.contains(e.target)) {
      navMenu.classList.remove('active');
      navToggle.classList.remove('active');
    }
  });

  // ============================================================
  // Scroll Animations (Intersection Observer)
  // ============================================================
  const animatedElements = document.querySelectorAll('.animate-on-scroll');

  if (animatedElements.length > 0 && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    });

    animatedElements.forEach(function (el) {
      observer.observe(el);
    });
  }

  // ============================================================
  // Reusable Premium Scroll Easing Function (Ease-In-Out Cubic)
  // ============================================================
  function smoothScrollTo(targetY, duration = 800) {
    const startY = window.scrollY || window.pageYOffset;
    const distance = targetY - startY;
    let startTime = null;

    // Cubic Easing Function: easeInOutCubic
    function easeInOutCubic(t) {
      return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    }

    function animation(currentTime) {
      if (startTime === null) startTime = currentTime;
      const timeElapsed = currentTime - startTime;
      const progress = Math.min(timeElapsed / duration, 1);
      const easedProgress = easeInOutCubic(progress);

      window.scrollTo(0, startY + distance * easedProgress);

      if (timeElapsed < duration) {
        requestAnimationFrame(animation);
      }
    }

    requestAnimationFrame(animation);
  }

  // ============================================================
  // Back to Top Button with Custom Scroll Easing
  // ============================================================
  const backToTop = document.querySelector('.back-to-top');

  if (backToTop) {
    window.addEventListener('scroll', function () {
      if (window.scrollY > 400) {
        backToTop.classList.add('visible');
      } else {
        backToTop.classList.remove('visible');
      }
    });

    backToTop.addEventListener('click', function () {
      smoothScrollTo(0, 800); // 800ms animation using custom Cubic Easing
    });
  }

  // ============================================================
  // Lightbox Gallery
  // ============================================================
  const galleryItems = document.querySelectorAll('.gallery-item');
  const lightbox = document.querySelector('.lightbox');
  const lightboxImg = lightbox ? lightbox.querySelector('img') : null;
  const lightboxClose = lightbox ? lightbox.querySelector('.lightbox__close') : null;

  if (galleryItems.length > 0 && lightbox && lightboxImg) {
    galleryItems.forEach(function (item) {
      item.addEventListener('click', function () {
        const img = this.querySelector('img');
        if (img) {
          lightboxImg.src = img.src;
          lightboxImg.alt = img.alt;
          lightbox.classList.add('active');
          document.body.style.overflow = 'hidden';
        }
      });
    });

    function closeLightbox() {
      lightbox.classList.remove('active');
      document.body.style.overflow = '';
    }

    if (lightboxClose) {
      lightboxClose.addEventListener('click', closeLightbox);
    }

    lightbox.addEventListener('click', function (e) {
      if (e.target === lightbox) {
        closeLightbox();
      }
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && lightbox.classList.contains('active')) {
        closeLightbox();
      }
    });
  }

  // ============================================================
  // Ticker duplication for seamless loop
  // ============================================================
  const tickerContent = document.querySelector('.ticker__content');
  if (tickerContent) {
    const items = tickerContent.innerHTML;
    tickerContent.innerHTML = items + items;
  }

  // ============================================================
  // Active Navigation Highlighting
  // ============================================================
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  const navLinks = document.querySelectorAll('.nav-menu__link');

  navLinks.forEach(function (link) {
    const href = link.getAttribute('href');
    if (href === currentPage || (currentPage === '' && href === 'index.html')) {
      link.classList.add('nav-menu__link--active');
    }
  });

  // ============================================================
  // Counter Animation for Stats
  // ============================================================
  function animateCounter(element, target, duration) {
    var start = 0;
    var startTime = null;

    function step(timestamp) {
      if (!startTime) startTime = timestamp;
      var progress = Math.min((timestamp - startTime) / duration, 1);
      var current = Math.floor(progress * target);
      element.textContent = current.toLocaleString('bn-BD');
      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        element.textContent = target.toLocaleString('bn-BD');
      }
    }

    requestAnimationFrame(step);
  }

  const statNumbers = document.querySelectorAll('.stat-card__number, .hero__stat-number');

  if (statNumbers.length > 0 && 'IntersectionObserver' in window) {
    const counterObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          var target = parseInt(entry.target.dataset.count || entry.target.textContent, 10);
          if (!isNaN(target)) {
            animateCounter(entry.target, target, 2000);
          }
          counterObserver.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.5
    });

    statNumbers.forEach(function (el) {
      counterObserver.observe(el);
    });
  }

  // ============================================================
  // Smooth scroll for anchor links with Custom Easing
  // ============================================================
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      var targetId = this.getAttribute('href');
      if (targetId === '#') return;
      var targetEl = document.querySelector(targetId);
      if (targetEl) {
        e.preventDefault();
        
        // Calculate offset position to account for the sticky main menu
        const navHeader = document.querySelector('.main-nav');
        const headerOffset = navHeader ? navHeader.offsetHeight : 60;
        const elementPosition = targetEl.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.scrollY - headerOffset;

        smoothScrollTo(offsetPosition, 900); // 900ms duration with custom Cubic Easing
      }
    });
  });

  // ============================================================
  // Filter buttons (Results / Gallery)
  // ============================================================
  const filterBtns = document.querySelectorAll('.filter-btn');
  filterBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      // Remove active from all
      this.parentElement.querySelectorAll('.filter-btn').forEach(function (b) {
        b.classList.remove('filter-btn--active');
      });
      this.classList.add('filter-btn--active');
    });
  });

  // ============================================================
  // Form Validation (Contact page)
  // ============================================================
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var valid = true;
      var inputs = this.querySelectorAll('.form-input[required]');

      inputs.forEach(function (input) {
        if (!input.value.trim()) {
          input.style.borderColor = '#e74c3c';
          valid = false;
        } else {
          input.style.borderColor = '';
        }
      });

      if (valid) {
        if (typeof Swal !== 'undefined') {
          Swal.fire({
            icon: 'success',
            title: 'বার্তা পাঠানো হয়েছে!',
            text: 'আপনার বার্তা সফলভাবে পাঠানো হয়েছে! ধন্যবাদ।',
            confirmButtonText: 'ঠিক আছে',
            confirmButtonColor: '#1c69b5'
          });
        } else {
          alert('আপনার বার্তা সফলভাবে পাঠানো হয়েছে! ধন্যবাদ।');
        }
        this.reset();
      }
    });
  }

  // ============================================================
  // Dynamic Header Admin/Login status
  // ============================================================
  const adminToken = localStorage.getItem('adminToken');
  const topBarLinks = document.querySelector('.top-bar__links');
  const mainNavMenu = document.getElementById('nav-menu');

  if (adminToken) {
    // 1. Update Top Bar Links: Show Dashboard & Logout
    if (topBarLinks) {
      topBarLinks.innerHTML = `
        <a href="admin.html" class="top-bar__link" id="login-link">🖥️ ড্যাশবোর্ড</a>
        <a href="#" class="top-bar__link" id="header-logout-btn">🔓 লগআউট</a>
      `;

      // Handle logout click
      const headerLogoutBtn = document.getElementById('header-logout-btn');
      if (headerLogoutBtn) {
        headerLogoutBtn.addEventListener('click', function (e) {
          e.preventDefault();
          if (typeof Swal !== 'undefined') {
            Swal.fire({
              title: 'লগআউট করতে চান?',
              text: 'আপনি ড্যাশবোর্ড সেশনটি বন্ধ করতে যাচ্ছেন।',
              icon: 'question',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'হ্যাঁ, লগআউট করুন',
              cancelButtonText: 'বাতিল'
            }).then((result) => {
              if (result.isConfirmed) {
                localStorage.removeItem('adminToken');
                localStorage.removeItem('adminUser');
                window.location.reload();
              }
            });
          } else {
            if (confirm('লগআউট করতে চান?')) {
              localStorage.removeItem('adminToken');
              localStorage.removeItem('adminUser');
              window.location.reload();
            }
          }
        });
      }
    }
    // 2. Append Admin Panel menu link to Main Navigation Menu
    if (mainNavMenu) {
      const adminMenuItem = document.createElement('li');
      adminMenuItem.className = 'nav-menu__item';
      adminMenuItem.setAttribute('role', 'none');
      adminMenuItem.innerHTML = `
        <a href="admin.html" class="nav-menu__link" role="menuitem" style="color: #e74c3c; font-weight: bold;">⚙️ এডমিন প্যানেল</a>
      `;
      mainNavMenu.appendChild(adminMenuItem);
    }
  }

  // 3. Apply Dynamic School Settings
  applyDynamicSchoolSettings();

});

// ============================================================
// Apply Dynamic School Settings globally from DB
// ============================================================
async function applyDynamicSchoolSettings() {
  if (typeof fetchSettings !== 'function') return;

  try {
    const settings = await fetchSettings();
    if (!settings) return;



    // 3. Update Footer Contact Column
    const footerContact = document.getElementById('footer-contact');
    if (footerContact) {
      const contactDivs = footerContact.querySelectorAll('.footer-contact');
      if (contactDivs.length >= 3) {
        const addressDiv = contactDivs[0].querySelector('div:not(.footer-contact__icon)');
        if (addressDiv && settings.address) {
          addressDiv.textContent = settings.address;
        }
        const phoneDiv = contactDivs[1].querySelector('div:not(.footer-contact__icon)');
        if (phoneDiv && settings.phone) {
          phoneDiv.textContent = settings.phone;
        }
        const emailDiv = contactDivs[2].querySelector('div:not(.footer-contact__icon)');
        if (emailDiv && settings.email) {
          emailDiv.textContent = settings.email;
        }
      }
    }

    // 4. Update Footer Social Links
    const socialFb = document.getElementById('social-fb');
    if (socialFb && settings.facebookLink) {
      socialFb.href = settings.facebookLink;
    }
    const socialYt = document.getElementById('social-yt');
    if (socialYt && settings.youtubeLink) {
      socialYt.href = settings.youtubeLink;
    }

  } catch (error) {
    console.error('Error applying dynamic school settings:', error);
  }
}
